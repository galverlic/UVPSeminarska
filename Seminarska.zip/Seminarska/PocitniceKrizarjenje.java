import java.util.*;

public class PocitniceKrizarjenje extends Pocitnice {
    private int stObiskanihMest;
    private int temperaturaMorja;

    public PocitniceKrizarjenje() {
        super();
    }

    public PocitniceKrizarjenje(int id, int najvecjeMoznoSteviloOseb, String drzava, int cena,
                    ArrayList<Termin> seznamTerminov, int stObiskanihMest, int temperaturaMorja) {

        super(id, najvecjeMoznoSteviloOseb, drzava, cena, seznamTerminov);
        this.stObiskanihMest = 0;
        this.temperaturaMorja = 0;
    }

    public int getstObiskanihMest() {
        return stObiskanihMest;
    }

    public void setstObiskanihMest(int stObiskanihMest) {
        this.stObiskanihMest = stObiskanihMest;
    }

    public int gettemperaturaMorja() {
        return temperaturaMorja;
    }

    public void settemperaturaMorja(int temperaturaMorja) {
        this.temperaturaMorja = temperaturaMorja;
    }

    @Override
    public String toString() {
        String PocitniceKrizarjenje = "\r\n------- PocitniceKrizarjenje -------\r\n";
        PocitniceKrizarjenje += "Stevilo obiskanih mest: " + this.stObiskanihMest + "\r\n";
        PocitniceKrizarjenje += "Drzava: " + this.getDrzava() + "\r\n";
        PocitniceKrizarjenje += "Temperatura morja : " + this.temperaturaMorja + "\r\n";
        PocitniceKrizarjenje += "Cena: " + this.getCena() + "\r\n";
        int i = 1;
        for (Termin t : this.getSeznamTerminov()) {
            PocitniceKrizarjenje += t.compressToString(this, i);
            i++;
        }
        PocitniceKrizarjenje += "--------------------\r\n";
        return PocitniceKrizarjenje;
    }

    public static PocitniceKrizarjenje readFromArray(ArrayList<String> data) {
        PocitniceKrizarjenje PocitniceKrizarjenje = new PocitniceKrizarjenje(); 
        try {
            PocitniceKrizarjenje.setId(Integer.parseInt(data.get(0)));
            PocitniceKrizarjenje.setNajvecjeMoznoSteviloOseb(Integer.parseInt(data.get(1)));
            PocitniceKrizarjenje.setStObiskanihMest(data.get(2));
            PocitniceKrizarjenje.setDrzava(data.get(3));
            PocitniceKrizarjenje.setTemperaturaMorja(data.get(4));
            PocitniceKrizarjenje.setCena(Integer.parseInt(data.get(5)));

            ArrayList<String> terminPodatki;

			for(int i=6; i < data.size(); i++) {
				if(data.get(i).trim().equals("*T")) {
                    terminPodatki = new ArrayList<String>();
					i++;

					while(i < data.size() &&!data.get(i).trim().equals("#")) {
						terminPodatki.add(data.get(i));
						i++;
					}

					Termin termin = Termin.readFromArray(terminPodatki);

					PocitniceKrizarjenje.dodajTermin(termin);
				}
			}

            return PocitniceKrizarjenje;
        } catch (Exception e) {
            System.out.println("\r\nERROR 404: Napak v vnosu podatkov, prosim prekinite progam in znova vnesite podatke!\r\n");
            throw e;
        }
    }

    private void setTemperaturaMorja(String string) {
    }

    private void setStObiskanihMest(String string) {
    }
}
