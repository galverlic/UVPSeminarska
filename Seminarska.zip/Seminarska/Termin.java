import java.util.*;
import java.time.*;
import java.time.format.*;

public class Termin {
    

    private int stVsehOseb;
    private LocalDate datumPrihoda;
    private LocalDate datumOdhoda;
    private boolean jeRezervirano;
    private int casPrihoda;
    private int casOdhoda;

    static DateTimeFormatter dateFormatter = new DateTimeFormatterBuilder().appendPattern("dd-MM-yyyy").toFormatter();

    public Termin() {
        this.stVsehOseb = 0;
        this.datumPrihoda = LocalDate.parse("01-01-2023", dateFormatter);
        this.datumOdhoda = LocalDate.parse("01-01-2023", dateFormatter);
        this.casPrihoda = 0;
        this.casOdhoda = 0;
    }

    public Termin(int stVsehOseb, LocalDate datumPrihoda, LocalDate datumOdhoda, int casPrihoda, int casOdhoda) {
        this.stVsehOseb = stVsehOseb;
        this.datumPrihoda = datumPrihoda;
        this.datumOdhoda = datumOdhoda;
        this.casPrihoda = casPrihoda;
        this.casOdhoda = casOdhoda;
    }
    public int getStVsehOseb() {
        return stVsehOseb;
    }

    public void setStVsehOseb(int stVsehOseb) {
        this.stVsehOseb = stVsehOseb;
    }

    public LocalDate getDatumPrihoda() {
        return datumPrihoda;
    }

    public int getCasPrihoda() {
        return casPrihoda;
    }

    public void setCasPrihoda(int casPrihoda) {
        this.casPrihoda = casPrihoda;
    }

    public int getCasOdhoda() {
        return casOdhoda;
    }

    public void setCasOdhoda(int casOdhoda) {
        this.casOdhoda = casOdhoda;
    }
    public void setDatumPrihoda(LocalDate datumPrihoda) {
        this.datumPrihoda = datumPrihoda;
    }

    public LocalDate getDatumOdhoda() {
        return datumOdhoda;
    }

    public void setDatumOdhoda(LocalDate datumOdhoda) {
        this.datumOdhoda = datumOdhoda;
    }

    public boolean isJeRezervirano() {
        return jeRezervirano;
    }

    public void setJeRezervirano(boolean jeRezervirano) {
        this.jeRezervirano = jeRezervirano;
    }
    
    public static LocalDate getDateFromString(String s) {
        return LocalDate.parse(s, dateFormatter);
    }

    public static String getStringFromDate(LocalDate date) {
        return date.format(dateFormatter);
    }

    public String compressToString(Pocitnice p, int i) {
        String termin = "";
        termin += "\r\n  === Termin " + i + " ===\r\n";
        termin += " Datum prihoda: " + Termin.getStringFromDate(this.getDatumPrihoda()) + "\r\n";
        termin += " Datum odhoda: " + Termin.getStringFromDate(this.getDatumOdhoda()) + "\r\n";
        termin += "  Cas prihoda: " + this.getCasPrihoda() + "\r\n";
        termin += "  Cas odhoda: " + this.getCasOdhoda() + "\r\n";


        String zasedenost;
        int nReserved = this.getStVsehOseb();
        if (nReserved == p.getNajvecjeMoznoSteviloOseb()) {
            zasedenost = "Termin je zagotovljen";
        } else if (nReserved > p.getNajvecjeMoznoSteviloOseb()/2 && nReserved < p.getNajvecjeMoznoSteviloOseb()) {
            zasedenost = "Termin je skoraj zagotovljen";
        } else {
            zasedenost = "Termin ni zagotovljen";
        }

        termin += "  Zasedenost: " + zasedenost + "\r\n";
        termin += "  =======\r\n";
        return termin;
    }

    public static Termin readFromArray(ArrayList<String> array) {
        Termin termin = new Termin();
        try {
            termin.setStVsehOseb(Integer.parseInt(array.get(1)));
            termin.setDatumPrihoda(Termin.getDateFromString(array.get(2)));
            termin.setDatumOdhoda(Termin.getDateFromString(array.get(3)));
            termin.setCasPrihoda(Integer.parseInt(array.get(4)));
            termin.setCasOdhoda(Integer.parseInt(array.get(5)));
            termin.setJeRezervirano((array.get(6).equals("true") ? true : false));
            return termin;
        } catch (Exception e) {
            System.out.println("\r\nERROR 404: Preveri podatke in znova vnesi v program!\r\n");
			throw e;
        }
    }
}
