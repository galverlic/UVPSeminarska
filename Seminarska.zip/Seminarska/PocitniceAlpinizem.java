import java.util.*;

public class PocitniceAlpinizem extends Pocitnice {   
    private String destinacija;
    private boolean potrebujemoUstreznoOpremo;

    public PocitniceAlpinizem() {
        super();
        this.destinacija = "";
        this.potrebujemoUstreznoOpremo = true;
    }

    public PocitniceAlpinizem(int id, int najvecjeMoznoSteviloOseb, String drzava, int cena,
                    ArrayList<Termin> seznamTerminov, String destinacija, boolean potrebujemoUstreznoOpremo) {

        super(id, najvecjeMoznoSteviloOseb, drzava, cena, seznamTerminov);

        this.destinacija = "";
        this.potrebujemoUstreznoOpremo = true;
    }

    public String getdestinacija() {
        return destinacija;
    }

    public void setdestinacija(String destinacija) {
        this.destinacija = destinacija;
    }

    public boolean getPotrebujemoUstreznoOpremo() {
        return potrebujemoUstreznoOpremo;
    }

    public void setpotrebujemoUstreznoOpremo(Boolean potrebujemoUstreznoOpremo) {
        this.potrebujemoUstreznoOpremo = potrebujemoUstreznoOpremo;
    }

    @Override
    public String toString() {
        String PocitniceAlpinizem = "\r\n---------- PocitniceAlpinizem ----------\r\n";
        PocitniceAlpinizem += "Destinacija: " + this.destinacija + "\r\n";
        PocitniceAlpinizem += "Drzava: " + this.getDrzava() + "\r\n";
        PocitniceAlpinizem += "Ali potrebujemo ustrezno opremo: " + (this.potrebujemoUstreznoOpremo ? "Da" : "Ne") + "\r\n";
        PocitniceAlpinizem += "Cena: " + this.getCena() + "\r\n";
        int i = 1;
        for (Termin t : this.getSeznamTerminov()) {
            PocitniceAlpinizem += t.compressToString(this, i);
            i++;
        }
        PocitniceAlpinizem += "------------------------\r\n";
        return PocitniceAlpinizem;
    }

    public static PocitniceAlpinizem readFromArray(ArrayList<String> data) {
        PocitniceAlpinizem PocitniceAlpinizem = new PocitniceAlpinizem(); 
        try {
            PocitniceAlpinizem.setId(Integer.parseInt(data.get(0)));
            PocitniceAlpinizem.setNajvecjeMoznoSteviloOseb(Integer.parseInt(data.get(1)));
            PocitniceAlpinizem.setdestinacija(data.get(2));
            PocitniceAlpinizem.setDrzava(data.get(3));
            PocitniceAlpinizem.setCena(Integer.parseInt(data.get(4)));
            PocitniceAlpinizem.setpotrebujemoUstreznoOpremo(data.get(5).equals("true") ? true : false);

            ArrayList<String> terminPodatki;

			for(int i=6; i < data.size(); i++) {
				if(data.get(i).trim().equals("*T")) {
                    terminPodatki = new ArrayList<String>();
					i++;

					while(i < data.size() &&!data.get(i).trim().equals("-")) {
						terminPodatki.add(data.get(i));
						i++;
					}

					Termin termin = Termin.readFromArray(terminPodatki);

					PocitniceAlpinizem.dodajTermin(termin);
				}
			}

            return PocitniceAlpinizem;
        } catch (Exception e) {
            System.out.println("\r\nERROR 404: Preosimo ponovno vnesite podatke!\r\n");
            throw e;
        }
    }
}
