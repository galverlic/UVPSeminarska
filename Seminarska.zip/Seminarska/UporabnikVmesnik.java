import java.io.*;

public class UporabnikVmesnik {
    public static void main(TuristicnaAgencija ta) throws Exception {
        System.out.println("r\n  ********** Dobrodosli v turisticni agenciji SKY'S THE LIMIT! *********** \r\n");

        InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);

        char izbira;

        while (ta.aliJePrijavljen()) {
            if (ta.getPrijavljenUporabnik().isaliJeAdministrator()) {
                System.out.println("Klikni (u) za izpis vseh uporabnikov.");
            }
            System.out.println("Klikni (a) za izpis vseh pocitnic.");
            System.out.println("Klikni (b) za iskanje pocitnice po casovnem okvirju.");
            System.out.println("Klikni (c) za iskanje pocitnice po drzavi.");
            System.out.println("Klikni (d) za iskanje pocitnice po cenovnem okvirju.");
            System.out.println("Klikni (e) za iskanje pocitnice po tipu.");
            System.out.println("Klikni (f) za rezervacijo novega termina.");
            System.out.println("Klikni (g) za ogled svoje rezervacije.");
            System.out.println("Klikni (q) za prekinitev programa.");

            izbira = br.readLine().trim().toLowerCase().charAt(0);

            switch(izbira) {
                case 'u':
                    if (ta.getPrijavljenUporabnik().isaliJeAdministrator()) {
                        for (Uporabnik u : ta.getSeznamUporabnikov()) {
                            System.out.println(u.toString());
                        }
                    }
                    break;

                case 'a':
                    ta.prikaziVsePocitnice();
                    break;

                case 'b':
                    ta.iskanjePocitnicPoCasovnemOkvirju();
                    break;

                case 'c':
                    ta.iskanjePocitnicPoDrzavi();
                    break;

                case 'd':
                    ta.iskanjePocitnicPoCenovnemOkvirju();
                    break;

                case 'e':
                    ta.prikaziPocitniceTip();
                    break;

                case 'f':
                    Rezervacija rezervacija = Rezervacija.dodajRezarvacija(ta.getPrijavljenUporabnik());
                    ta.rezervirajTermin(rezervacija);
                    break;

                case 'g':
                    for (Rezervacija r : ta.getseznamRezervacij()) {
                        if (r.getuporabniskoIme().equals(ta.getPrijavljenUporabnik().getUporabniskoIme())) {
                            System.out.println(r.toString());
                        }
                    }
                    break;

              
                case 'q':
                    return;

                default:
					System.out.println("ERROR 404: Kliknili ste gumb brez dodeljenega pomena!");
					System.out.println();
            }
        }
    }

}
