import java.util.*;

public class PocitniceKampiranje extends Pocitnice {
    private String destinacija;
    private boolean potrebujemoSotor;

    public PocitniceKampiranje() {
        super();
        this.destinacija = "";
        this.potrebujemoSotor = true;
    }

    public PocitniceKampiranje(int id, int najvecjeMoznoSteviloOseb, String drzava, int cena,
                    ArrayList<Termin> seznamTerminov, String destinacija, boolean potrebujemoSotor) {

        super(id, najvecjeMoznoSteviloOseb, drzava, cena, seznamTerminov);
        this.destinacija = "";
        this.potrebujemoSotor = false;
    }

    public String getdestinacija() {
        return destinacija;
    }

    public void setdestinacija(String destinacija) {
        this.destinacija = destinacija;
    }

    public boolean getpotrebujemoSotor() {
        return potrebujemoSotor;
    }

    public void setpotrebujemoSotor(boolean potrebujemoSotor) {
        this.potrebujemoSotor = potrebujemoSotor;
    }

    @Override
    public String toString() {
        String PocitniceKampiranje = "\r\n--------- Pocitnice Kampiranje -----------\r\n";
        PocitniceKampiranje += "Destinacija: " + this.destinacija + "\r\n";
        PocitniceKampiranje += "Drzava: " + this.getDrzava() + "\r\n";
        PocitniceKampiranje += "Cena: " + this.getCena() + "\r\n";
        PocitniceKampiranje += "Potrebujete sotor: " + (this.potrebujemoSotor ? "Da" : "Ne") + "\r\n";
        int i = 1;
        for (Termin t : this.getSeznamTerminov()) {
            PocitniceKampiranje += t.compressToString(this, i);
            i++;
        }
        PocitniceKampiranje += "--------------------\r\n";
        return PocitniceKampiranje;
    }

    public static PocitniceKampiranje readFromArray(ArrayList<String> data) {
        PocitniceKampiranje PocitniceKampiranje = new PocitniceKampiranje(); 
        try {
            PocitniceKampiranje.setId(Integer.parseInt(data.get(0)));
            PocitniceKampiranje.setNajvecjeMoznoSteviloOseb(Integer.parseInt(data.get(1)));
            PocitniceKampiranje.setdestinacija(data.get(2));
            PocitniceKampiranje.setDrzava(data.get(3));
            PocitniceKampiranje.setpotrebujemoSotor(data.get(4).equals("true") ? true : false);
            PocitniceKampiranje.setCena(Integer.parseInt(data.get(5)));

            ArrayList<String> terminPodatki;

			for(int i=6; i < data.size(); i++) {
				if(data.get(i).trim().equals("*T")) {
                    terminPodatki = new ArrayList<String>();
					i++;

					while(i < data.size() &&!data.get(i).trim().equals("-")) {
						terminPodatki.add(data.get(i));
						i++;
					}

					Termin termin = Termin.readFromArray(terminPodatki);

					PocitniceKampiranje.dodajTermin(termin);
				}
			}

            return PocitniceKampiranje;
        } catch (Exception e) {
            System.out.println("\r\nERROR 404: Prosimo ponovno zazenite program in pravilno vnesite podatke!\r\n");
            throw e;
        }
    }
}
