import java.util.ArrayList;


public class Pocitnice {
	
    private int id;
    private int najvecjeMoznoSteviloOseb;
	private String drzava;
	private double cena;
	private ArrayList<Termin> seznamTerminov;
	
	
	public Pocitnice() {
        this.id = (int)Math.floor(Math.random()*(999-100+1)+100); 
        this.najvecjeMoznoSteviloOseb = 100;
        this.drzava = "";
        this.cena = 0;
        this.seznamTerminov = new ArrayList<Termin>();
    }

    public Pocitnice(int id, int najvecjeMoznoSteviloOseb, String drzava, int cena, ArrayList<Termin> seznamTerminov) {
        this.id = id;
        this.najvecjeMoznoSteviloOseb = najvecjeMoznoSteviloOseb;
        this.drzava = drzava;
        this.cena = cena;
        this.seznamTerminov = seznamTerminov;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNajvecjeMoznoSteviloOseb() {
        return najvecjeMoznoSteviloOseb;
    }
    public void setNajvecjeMoznoSteviloOseb(int najvecjeMoznoSteviloOseb) {
        this.najvecjeMoznoSteviloOseb = najvecjeMoznoSteviloOseb;
    }

    public String getDrzava() {
        return drzava;
    }

    public void setDrzava(String drzava) {
        this.drzava = drzava;
    }

    public double getCena() {
        return cena;
    }

    public void setCena(int cena) {
        this.cena = cena;
    }

    public ArrayList<Termin> getSeznamTerminov() {
        return seznamTerminov;
    }

    public void setSeznamTerminov(ArrayList<Termin> seznamTerminov) {
        this.seznamTerminov = seznamTerminov;
    }

    public void dodajTermin(Termin termin) {
        this.seznamTerminov.add(termin);
    }
    public static void main(String args) {}


}
