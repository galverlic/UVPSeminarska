import java.util.*;

public class PocitnicePotovanje extends Pocitnice  {
    private String destinacija;
    private int cenaLetalskeVozovnice;

    public PocitnicePotovanje() {
        super();
        this.destinacija = "";
        this.cenaLetalskeVozovnice = 0;
    }

    public PocitnicePotovanje(int id, int najvecjeMoznoSteviloOseb, String drzava, int cena,
                    ArrayList<Termin> seznamTerminov, String destinacija, int cenaLetalskeVozovnice) {

        super(id, najvecjeMoznoSteviloOseb, destinacija, cena, seznamTerminov);
        this.destinacija = "";
        this.cenaLetalskeVozovnice = 0;
    }

    public String getdestinacija() {
        return destinacija;
    }

    public void setdestinacija(String destinacija) {
        this.destinacija = destinacija;
    }

    public int getletalo() {
        return cenaLetalskeVozovnice;
    }

    public void setletalo(int cenaLetalskeVozovnice) {
        this.cenaLetalskeVozovnice = cenaLetalskeVozovnice;
    }

    @Override
    public String toString() {
        String PocitnicePotovanje = "\r\n------- Pocitnice potovanje -------\r\n";
        PocitnicePotovanje += "Destinacija: " + this.destinacija + "\r\n";
        PocitnicePotovanje += "Drzava destinacije: " + this.getDrzava() + "\r\n";
        PocitnicePotovanje += "Cena potovanja: " + this.getCena() + "\r\n";
        PocitnicePotovanje += "Cena letalske vozovnice: " + this.cenaLetalskeVozovnice + "\r\n";
        int i = 1;
        for (Termin t : this.getSeznamTerminov()) {
            PocitnicePotovanje += t.compressToString(this, i);
            i++;
        }
        PocitnicePotovanje += "-----------------------\r\n";
        return PocitnicePotovanje;
    }

    public static PocitnicePotovanje readFromArray(ArrayList<String> data) {
        PocitnicePotovanje PocitnicePotovanje = new PocitnicePotovanje(); 
        try {
            PocitnicePotovanje.setId(Integer.parseInt(data.get(0)));
            PocitnicePotovanje.setNajvecjeMoznoSteviloOseb(Integer.parseInt(data.get(1)));
            PocitnicePotovanje.setdestinacija(data.get(2));
            PocitnicePotovanje.setDrzava(data.get(3));
            PocitnicePotovanje.setCena(Integer.parseInt(data.get(4)));
            PocitnicePotovanje.setletalo(Integer.parseInt(data.get(5)));

            ArrayList<String> terminPodatki;

			for(int i=6; i < data.size(); i++) {
				if(data.get(i).trim().equals("*T")) {
                    terminPodatki = new ArrayList<String>();
					i++;

					while(i < data.size() &&!data.get(i).trim().equals("-")) {
						terminPodatki.add(data.get(i));
						i++;
					}

					Termin termin = Termin.readFromArray(terminPodatki);

					PocitnicePotovanje.dodajTermin(termin);
				}
			}

            return PocitnicePotovanje;
        } catch (Exception e) {
            System.out.println("\r\nERROR 404: Prosimo ponovno vnesite podatke!\r\n");
            throw e;
        }
    }
}
