import java.io.BufferedReader;
import java.io.InputStreamReader;

public class UporabniskiVmesnik {
	public static void main(String[] args) throws Exception {

	//metode 
		TuristicnaAgencija ta = new TuristicnaAgencija();

		ta.readFromFile("pocitnice.txt");
		ta.readFromFile("rezervacije.txt");
		ta.readFromFile("users.txt");

         InputStreamReader isr = new InputStreamReader(System.in);
		 BufferedReader br = new BufferedReader(isr);	

        System.out.println("\r\n*****************DOBRODOSLI V TURISTICNI AGENCIJI SKY'S THE LIMIT!*******************\r\n");

		char izbira;
		
		while(!ta.aliJePrijavljen()) {
			System.out.println("Kliknite (p) za prijavo v program.");
			System.out.println("Kliknite (r) za ustvarjanje racuna.");
			System.out.println("Kliknite (q) za prekinitev programa.");
			System.out.println();
			
			izbira = br.readLine().trim().toLowerCase().charAt(0);
			
			switch(izbira) {
				case 'p':
					ta.prijava();
					break;
				case 'r':
					Uporabnik user = Uporabnik.ustvariUporabnik();
					ta.novUporabnik(user);
					break;
				case 'q':
					return;
				default:
					System.out.println("Pritisnili ste napacno izbiro!");
					System.out.println();
			}
		}

		if(ta.aliJePrijavljen()) {
			UporabnikVmesnik.main(ta);
		}
		
	}
	
}


























