import java.io.*;
import java.util.*;
import java.time.*;

public class TuristicnaAgencija {
    private Uporabnik prijavljenUporabnik;
    private ArrayList<Uporabnik> seznamUporabnikov;
    private ArrayList<Pocitnice> seznamPocitnic;
    private ArrayList<Rezervacija> seznamRezervacij;
    private ArrayList<Termin> seznamTerminov;

    public TuristicnaAgencija() {
        this.prijavljenUporabnik = null;
        this.seznamUporabnikov = new ArrayList<Uporabnik>();
        this.seznamPocitnic = new ArrayList<Pocitnice>();
        this.seznamRezervacij = new ArrayList<Rezervacija>();
    }

    public TuristicnaAgencija(Uporabnik prijavljenUporabnik, ArrayList<Uporabnik> seznamUporabnikov,
                            ArrayList<Pocitnice> seznamPocitnic, ArrayList<Rezervacija> seznamRezervacij) {
        this.prijavljenUporabnik = prijavljenUporabnik;
        this.seznamUporabnikov = seznamUporabnikov;
        this.seznamPocitnic = seznamPocitnic;
        this.seznamRezervacij = seznamRezervacij;
    }

    // getters 
    public Uporabnik getPrijavljenUporabnik() {
        return this.prijavljenUporabnik;
    }
    public ArrayList<Uporabnik> getSeznamUporabnikov() {
        return this.seznamUporabnikov;
    }
    public ArrayList<Pocitnice> getseznamPocitnic() {
        return this.seznamPocitnic;
    }
    public ArrayList<Rezervacija> getseznamRezervacij() {
        return this.seznamRezervacij;
    }
    public ArrayList<Termin> getseznamTerminov() {
        return this.seznamTerminov;
    }

    // setterji
    public void setPrijavljenUporabnik(Uporabnik prijavljenUporabnik) {
        this.prijavljenUporabnik = prijavljenUporabnik;
    }

    public boolean aliJePrijavljen() {
        return this.prijavljenUporabnik == null ? false : true;
    }

    

    public void setSeznamUporabnikov(ArrayList<Uporabnik> seznamUporabnikov) {
        this.seznamUporabnikov = seznamUporabnikov;
    }

    public void setseznamPocitnic(ArrayList<Pocitnice> seznamPocitnic) {
        this.seznamPocitnic = seznamPocitnic;
    }

   

    public void setseznamRezervacij(ArrayList<Rezervacija> seznamRezervacij) {
        this.seznamRezervacij = seznamRezervacij;
    }


    public void setseznamTerminov(ArrayList<Termin> seznamTerminov) {
        this.seznamTerminov = seznamTerminov;
    }

    public void prijava() throws Exception {
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);

        while (true) {
            System.out.println("\r\nVnesite uporabnisko ime:\r\n");
            String username = br.readLine().trim();
            System.out.println("\r\nVnesite geslo:\r\n");
            String password = br.readLine().trim();

            boolean prijavljen = false;

            for (Uporabnik u : this.seznamUporabnikov) {
                if (username.equals(u.getUporabniskoIme()) && password.equals(u.getGeslo())) {
                    this.prijavljenUporabnik = u;
                    prijavljen = true;
                    System.out.println("\r\nPrijava je bila uspesna.\r\n");
                    System.out.println(u.toString());
                    return;
                }
            }

            if (!prijavljen) {
                System.out.println("\r\nUporabnik s tem uporabniskim imenom in geslom ne obstaja! Prosimo vnesite podatke ponovno ali ustvarite nov racun.\r\n");
            }
        }
    }

    public void shraniUporabnika(String fileName) throws IOException {
        FileWriter fw = new FileWriter(fileName, false);
		PrintWriter file = new PrintWriter(fw);

        for (Uporabnik u : this.seznamUporabnikov) {
            file.print(u.compressAsString());
        }

        file.close();
    }

    // Preverjanje ce uporabnik s tem imenom ne obstaja, potem ga doda v users.txt 
    public void novUporabnik(Uporabnik user) {
        boolean helper = false;
		
		for(Uporabnik u : this.seznamUporabnikov) {
			if(u.getUporabniskoIme().equals(user.getUporabniskoIme())) {
				helper = true;
				break;
			}
		}
		
		if(!helper) {
			this.seznamUporabnikov.add(user);
            System.out.println("Registracija je bila uspesna!");
            try {
                this.shraniUporabnika("users.txt");
            } catch (Exception e) {
                System.out.println("ERROR 404: Preveri podatke!");
            }
		}
		else {
			System.out.println("\r\nUporabnik s tem uporabniskim imenom ze obstaja, prosimo prijavite se v program s tem uporabniskim imenom!\r\n");
		}
    }

    public void shraniRezervacijo(String fileName) throws IOException {
        FileWriter fw = new FileWriter(fileName, false);
		PrintWriter file = new PrintWriter(fw);

        /*for (Rezervacija r : this.seznamRezervacij) {
            file.print(r.compressAsString());
        }
        */
        file.close();
    }

    public void rezervirajTermin(Rezervacija r) {
        for (Pocitnice p : this.seznamPocitnic) {
            for (Termin t : p.getSeznamTerminov()) {
                //if (t.getId() == r.getTerminId()) { 
                    int rSteviloOseb = r.getstOdraslih() + r.getstOtrok();
                    int terminProsto = p.getNajvecjeMoznoSteviloOseb() - t.getStVsehOseb();
                    if (rSteviloOseb <= terminProsto) {
                        t.setStVsehOseb(t.getStVsehOseb() + rSteviloOseb);
                        this.getPrijavljenUporabnik().dodajRezervacija(r);
                        this.seznamRezervacij.add(r);
                        try {
                            this.shraniRezervacijo("rezervacije.txt");
                            System.out.println("\r\nRezervacija je uspesno ustvarjena!\r\n");
                            //System.out.println(t.compressToString(p, t.getId()));
                        } catch (Exception e) {
                            System.out.println("ERROR 404!");
                        }
                    } else {
                        System.out.println("\r\nERROR 404: Ni prostih mest za zeljen termin\r\n");
                    }
                    break;
                }
            }
        }
   // }

   /* public void obnoviTermin(Termin obnovenTermin, ArrayList<Termin> seznamTerminov) {
        for (Termin t : seznamTerminov) {
            if (t.getId() == obnovenTermin.getId()) {
                t.setSteviloOsebRezervirano(obnovenTermin.getSteviloOsebRezervirano());
            }
        }
    }*/

    public void readFromFile(String fileName) throws Exception {
        FileReader fr = new FileReader(fileName);
		BufferedReader file = new BufferedReader(fr);

		ArrayList<String> data;

        while (file.ready()) {

            String row = file.readLine().trim();

            if(row.equals("*U")) {
				data = new ArrayList<String>();
				while(file.ready() && !row.equals("---")) {
					row = file.readLine().trim();
					data.add(row);
				}
				Uporabnik newUser = Uporabnik.readFromArray(data);
				this.seznamUporabnikov.add(newUser);
			} else if (row.equals("*Rez")) {
                data = new ArrayList<String>();
                while (file.ready() && !row.equals("---")) {
                    row = file.readLine().trim();
					data.add(row);
                }
                Rezervacija rezervacija = Rezervacija.readFromArray(data);
                this.seznamRezervacij.add(rezervacija);
            } else if (row.equals("*PP")) {
                data = new ArrayList<String>();
                while (file.ready() && !row.equals("---")) {
                    row = file.readLine().trim();
					data.add(row);
                }
                PocitnicePotovanje pocitnicePotovanje = PocitnicePotovanje.readFromArray(data);
                this.seznamPocitnic.add(pocitnicePotovanje);
            } else if (row.equals("*PAl")) {
                data = new ArrayList<String>();
                while (file.ready() && !row.equals("---")) {
                    row = file.readLine().trim();
					data.add(row);
                }
                PocitniceAlpinizem pocitniceAlpinizem = PocitniceAlpinizem.readFromArray(data);
                this.seznamPocitnic.add(pocitniceAlpinizem);
            } else if (row.equals("*PK")) {
                data = new ArrayList<String>();
                while (file.ready() && !row.equals("---")) {
                    row = file.readLine().trim();
					data.add(row);
                }
                PocitniceKampiranje pocitniceKampiranje = PocitniceKampiranje.readFromArray(data);
                this.seznamPocitnic.add(pocitniceKampiranje);
            } else if (row.equals("*PKr")) {
                data = new ArrayList<String>();
                while (file.ready() && !row.equals("---")) {
                    row = file.readLine().trim();
					data.add(row);
                }
                PocitniceKrizarjenje pocitniceKrizarjenje = PocitniceKrizarjenje.readFromArray(data);
                this.seznamPocitnic.add(pocitniceKrizarjenje);
            }

        }

        file.close();
    }

    public void prikaziVsePocitnice() {
        System.out.println("\r\n************* SEZNAM VSEH POCITNIC ***********");
        for (Pocitnice p : this.seznamPocitnic) {
            System.out.println(p.toString());
        }
    }

    // Iskanje pocitnic po datumu in casu
    public void iskanjePocitnicPoCasovnemOkvirju() throws Exception {
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);

        try {
            System.out.println("\r\nVnesite datum od (format MESEC-DAN-LETO):\r\n");
            String inputOd = br.readLine().trim().toLowerCase();
            LocalDate dateFrom = Termin.getDateFromString(inputOd);
            System.out.println("\r\nVnesite datum do (format MESEC-DAN-LETO):\r\n");
            String inputDo = br.readLine().trim().toLowerCase();
            LocalDate dateTo = Termin.getDateFromString(inputDo);

            boolean found = false;
    
            for (Pocitnice p : this.seznamPocitnic) {
                boolean terminFound = false;
                for (Termin t : p.getSeznamTerminov()) {
                    if (t.getDatumPrihoda().isAfter(dateFrom) && t.getDatumOdhoda().isBefore(dateTo)) {
                        terminFound = true;
                        found = true;
                    }
                }
                if (terminFound) System.out.println(p.toString());
            }

            if (!found) System.out.println("V tem casovnem okvirju ninobenih pocitnic na voljo!");
        } catch (Exception e) {
            System.out.println("\r\nERROR 404: Preverite vas zapis datuma!\r\n");
        }
    }

    // Iskanje pocitnic po drzavi
    public void iskanjePocitnicPoDrzavi() throws Exception {
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);

        System.out.println("\r\nVnesite drzavo: \r\n");

        String input = br.readLine().trim().toLowerCase();
        boolean found = false;

        for (Pocitnice p : this.seznamPocitnic) {
            if (p.getDrzava().toLowerCase().equals(input)) {
                found = true;
                System.out.println(p.toString());
            }
        }

        if (!found) System.out.println("\r\nV izbrani drzavi ni bilo najdenih nobenih pocitnic. Preverite zapis ali izberite drugo drzavo.\r\n");
    }

    // Iskanje pocitnic po cenovnem okvirju
    public void iskanjePocitnicPoCenovnemOkvirju() throws Exception {
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);

        System.out.println("\r\nVnesi minimalno ceno: \r\n");
        Integer minCena = Integer.parseInt(br.readLine().trim());
        System.out.println("\r\nVnesi maksimalno ceno: \r\n");
        Integer maxCena = Integer.parseInt(br.readLine().trim());
        boolean found = false;

        for (Pocitnice p : this.seznamPocitnic) {
            if (p.getCena() > minCena && p.getCena() < maxCena) {
                found = true;
                System.out.println(p.toString());
            }
        }

        if (!found) System.out.println("\r\n Za ta cenovni okvir ni bilo najdenih nobenih pocitnic.\r\n");
    }

    // Iskanje pocitnic po tipu pocitnic
    public void prikaziPocitniceTip() throws Exception {
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);

        System.out.print("\r\n Tipi pocitnic: Potovanje, Krizarjenje, Kampiranje, Alpinizem.\r\n");

        String input = br.readLine().trim().toLowerCase();
        boolean found = false;

        switch (input) {
            case "Potovanje":
                for (Pocitnice p : this.seznamPocitnic) {
                    if (p instanceof PocitnicePotovanje) {
                        found = true;
                        System.out.println(p.toString());
                    }
                }
                break;

            case "Krizarjenje":
                for (Pocitnice p : this.seznamPocitnic) {
                    if (p instanceof PocitniceKrizarjenje) {
                        found = true;
                        System.out.println(p.toString());
                    }
                }
                break;

            case "Kampiranje":
                for (Pocitnice p : this.seznamPocitnic) {
                    if (p instanceof PocitniceKampiranje) {
                        found = true;
                        System.out.println(p.toString());
                    }
                }
                break;

            case "Alpinizem":
                for (Pocitnice p : this.seznamPocitnic) {
                    if (p instanceof PocitniceAlpinizem) {
                        found = true;
                        System.out.println(p.toString());
                    }
                }
                break;

            default:
                found = true;
                System.out.println("\r\n ERROR 404!\r\n");
                break;
        }

        if (!found) System.out.println("\r\nPocitnicec tipa: '" + input + "' nimamo na voljo.\r\n");
    }

}
