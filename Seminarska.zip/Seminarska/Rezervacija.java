import java.io.*;
import java.util.*;

public class Rezervacija {
    private String ime;
    private String priimek;
    private String uporabniskoIme;
    private int stOdraslih;
    private int stOtrok;

    public Rezervacija() {
        this.ime = "";
        this.priimek = "";
        this.uporabniskoIme = "";
        this.stOdraslih = 0;
        this.stOtrok = 0;
    }

    public Rezervacija(String ime, String priimek, String uporabniskoIme, int stOdraslih,
                        int stOtrok) {
        this.ime = ime;
        this.priimek = priimek;
        this.uporabniskoIme = uporabniskoIme;
        this.stOdraslih = stOdraslih;
        this.stOtrok = stOtrok;
    }

    public String getime() {
        return ime;
    }

    public void setime(String ime) {
        this.ime = ime;
    }

    public String getpriimek() {
        return priimek;
    }

    public void setpriimek(String priimek) {
        this.priimek = priimek;
    }

    public String getuporabniskoIme() {
        return uporabniskoIme;
    }

    public void setuporabniskoIme(String uporabniskoIme) {
        this.uporabniskoIme = uporabniskoIme;
    }

    public int getstOdraslih() {
        return stOdraslih;
    }

    public void setstOdraslih(int stOdraslih) {
        this.stOdraslih = stOdraslih;
    }

    public int getstOtrok() {
        return stOtrok;
    }

    public void setstOtrok(int stOtrok) {
        this.stOtrok = stOtrok;
    }
/*
    public String compressAsString() {
        String rezervacija = "*R\r\n";
        rezervacija += this.ime + "\r\n";
        rezervacija += this.priimek + "\r\n";
        rezervacija += this.uporabniskoIme + "\r\n";
        rezervacija += this.stOdraslih + "\r\n";
        rezervacija += this.stOtrok + "\r\n";
        rezervacija += "##\r\n";

		return rezervacija;
    }
*/
    @Override
    public String toString() {
        String rezervacija = "\r\n------- Rezervacija -------\r\n";
        rezervacija += "Stevilo odraslih oseb: " + this.stOdraslih + "\r\n";
        rezervacija += "Stevilo otrok: " + this.stOtrok + "\r\n";
        rezervacija += "-----------------------\r\n";
        return rezervacija;
    }

    public static Rezervacija dodajRezarvacija(Uporabnik user) throws Exception {
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);


        System.out.println("\r\nVnesi stevilo odraslih oseb: \r\n");
        int stOdraslih = Integer.parseInt(br.readLine().trim());
        System.out.println();

        System.out.println("\r\nVnesi stevilo otrok: \r\n");
        int stOtrok = Integer.parseInt(br.readLine().trim());
        System.out.println();

        Rezervacija rezervacija = new Rezervacija(user.getIme(), user.getPriimek(), user.getUporabniskoIme(), stOdraslih, stOtrok);

        return rezervacija;
    }

    public static Rezervacija readFromArray(ArrayList<String> input) {
        Rezervacija rezervacija = new Rezervacija();
        try {
            rezervacija.setime(input.get(0));
            rezervacija.setpriimek(input.get(1));
            rezervacija.setuporabniskoIme(input.get(2));
            rezervacija.setstOdraslih(Integer.parseInt(input.get(3)));
            rezervacija.setstOtrok(Integer.parseInt(input.get(4)));
            return rezervacija;
        } catch (Exception e) {
            System.out.println("ERROR 404: Prosim prekinite program in znova vnesite podatke!\r\n");
            throw e;
        }
    }
}
