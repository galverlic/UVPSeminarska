import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.ArrayList;

public class TuristicnaAgencija {
    // Shranjuje seznam pocitnic tipa Pocitnice(naj se preberejo iz datoteke ob zagonu programa)
    // Omogoca upravljanje s turisticno agencijo

    //readerji in nastavki
    static ArrayList<Pocitnice> pocitnice = new ArrayList<>();
	private static BufferedReader br = null;
	private static PrintWriter pw = null;
	public static Uporabnik uporabnik = null;
	
	public static void load() throws ClassNotFoundException, IOException {
		IOReadAndWrite.readLoadObject(UporabniskiVmesnik.pot2, pocitnice);
	}
	public static void save() throws ClassNotFoundException, IOException {
		IOReadAndWrite.saveObject(UporabniskiVmesnik.pot2,pocitnice);
	}
	
    //preverimo st rezervacij
	public static int stRezervacij(Pocitnice obj) {
		int vsota = 0 ;
		if(obj.getRezervacije() == null || obj.getRezervacije().isEmpty()) 
			obj.setRezervacije(new ArrayList<>());
		for(Rezervacija re: obj.getRezervacije()) {
			vsota += re.getStOdraslih() + re.getStOtrok();
		}
		return vsota;
	}
	

	public static void iskanjeCasovniOkvir(boolean flag) throws IOException {
		int danPrihoda = 0;
        int mesecPrihoda = 0;
        int danOdhoda = 0;
        int mesecOdhoda = 0;

		boolean aliObstajajoPocitnice = false;
		br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Dan prihoda: ");
		danPrihoda = betterIntegerParser_helper(br.readLine());
		System.out.println("Mesec prihoda: ");
		mesecPrihoda = betterIntegerParser_helper(br.readLine());
        System.out.println("Dan odhoda: ");
		danOdhoda = betterIntegerParser_helper(br.readLine());
		System.out.println("Mesec odhoda: ");
		mesecOdhoda = betterIntegerParser_helper(br.readLine());
		
		for(Pocitnice obj: pocitnice)
		{
			
			if(obj.getTermini().size() > 0 && obj.getDan() < danOdhoda && obj.getMesec() < mesecOdhoda && obj.getDan() > danPrihoda && obj.getDan() > mesecPrihoda) {
				aliObstajajoPocitnice = true;
				System.out.println( flag ? obj : obj.toStringUporabnik());
				System.out.println("Za te pocitnice so prosti naslednji termini: ");
                //pregledamo mozne termine
				for(Termin ter: obj.getTermini()) {
                    // ce je stevilo rezervacij enako stevilu prostih mest
					if(stRezervacij(obj) <= obj.getProstaMesta())
						System.out.println(ter + "\n Vasa rezervacija je zagotovljena.");
                     //st rezervacij je manj kot je prostih mest   
					else if(stRezervacij(obj) < obj.getProstaMesta())
						System.out.println(ter +"\nVasa rezervacija je skoraj zagotovljena.");
                     // drugace pa   
					else
						System.out.println(ter +"\nVasa rezeracija ni zagotovljena.");
				createReservation(obj);
				}
			}
				
		}
		System.out.println(aliObstajajoPocitnice ? "" : "Error 404:Ni mozno rezervirati takih pocitnic.");
		
	}
	public static void iskanjeDrzava(boolean flag) throws IOException {
		String drzava = "";
		boolean aliObstajajoPocitnice = false;
		br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Drzava: ");
		drzava = br.readLine();
		
		for(Pocitnice obj: pocitnice)
		{
			if(obj.getTermini().size() > 0 && obj.getDrzava().equals(drzava)) {
				aliObstajajoPocitnice = true;
				System.out.println( flag ? obj : obj.toStringUporabnik());
				System.out.println("Prosti so naslednji termini: ");
				for(Termin ter: obj.getTermini())
					if(stRezervacij(obj) == obj.getProstaMesta())
						System.out.println(ter + "\n ZAGOTOVLJENO.");
					else if(stRezervacij(obj) < obj.getProstaMesta())
						System.out.println(ter +"\n SKORAJ ZAGOTOVLJENO.");
					else
						System.out.println(ter +"\nNI ZAGOTOVLJENO.PREVEC OSEB!!");
				createReservation(obj);
			}
				
		}
		System.out.println(aliObstajajoPocitnice ? "" : "Pocitnice ni bilo mogoce najti.");
	}
	public static void iskanjeCenovniOkvir(boolean flag) throws IOException {
		int minCena = 0, maxCena = 0;
		boolean aliObstajajoPocitnice = false;
		br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Minimalna cena: ");
		minCena = betterIntegerParser_helper(br.readLine());
		System.out.print("Maksimalna cena: ");
		maxCena = betterIntegerParser_helper(br.readLine());
		
		for(Pocitnice obj: pocitnice)
		{
			if(obj.getTermini().size() > 0 && obj.getCena() >= minCena && obj.getCena() <= maxCena) {
				aliObstajajoPocitnice = true;
				System.out.println( flag ? obj : obj.toStringUporabnik());
				System.out.println("Prosti so naslednji termini: ");
				for(Termin ter: obj.getTermini()) {
					if(stRezervacij(obj) == obj.getProstaMesta())
						System.out.println(ter + "\n ZAGOTOVLJENO.");
					else if(stRezervacij(obj) < obj.getProstaMesta())
						System.out.println(ter +"\n SKORAJ ZAGOTOVLJENO.");
					else
						System.out.println(ter +"\n NI ZAGOTOVLJENO.");
				createReservation(obj);
				}
			}
		}
		System.out.println(aliObstajajoPocitnice ? "" : "Pocitnice ni bilo mogoce najti.");
	}
	public static void iskanjePoTipuPocitnic(boolean flag) throws IOException {
		char ch = ' ';
		boolean aliObstajajoPocitnice = false;
		br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Pritisnite na eno od opcij: ");
		System.out.println("Na voljo so naslednji tipi: ");
        System.out.println("a -> alpinizem: ");
		System.out.println("b -> krizarjanje: ");
		System.out.println("c -> potovanje: ");
		System.out.println("d -> kampiranje: ");
		System.out.print("Vnesite crko(izbiro): ");
		ch = (char) br.read();
		
		switch (ch) {
		case 'a': {
			for(Pocitnice obj: pocitnice)
			{
				
				if(obj.getTermini().size() > 0 && obj instanceof PocitniceAlpinizem)
				{
					aliObstajajoPocitnice = true;
					System.out.println( flag ? obj : obj.toStringUporabnik());
					System.out.println("Za te pocitnice so prosti naslednji termini: ");
					for(Termin ter: obj.getTermini()) {
						if(stRezervacij(obj) == obj.getProstaMesta())
							System.out.println(ter + "\nZAGOTOVLJENO.");
						else if(stRezervacij(obj) < obj.getProstaMesta())
							System.out.println(ter +"\nSKORAJ ZAGOTOVLJENO.");
						else
							System.out.println(ter +"\nNI ZAGOTOVLJENO.");
						createReservation(obj);
					}
				}
			}
			break;
		}
		case 'b': {
			for(int i=0;i<pocitnice.size();i++)
			{
				if(pocitnice.get(i).getTermini().size() > 0 && pocitnice.get(i) instanceof PocitniceKrizarjenje)
				{
					aliObstajajoPocitnice = true;
					System.out.println( flag ? pocitnice.get(i) : pocitnice.get(i).toStringUporabnik());
					System.out.println("Prosti so naslednji termini: ");
					for(Termin ter: pocitnice.get(i).getTermini()) {
						if(stRezervacij(pocitnice.get(i)) == pocitnice.get(i).getProstaMesta())
							System.out.println(ter + "\n ZAGOTOVLJENO.");
						else if(stRezervacij(pocitnice.get(i)) < pocitnice.get(i).getProstaMesta())
							System.out.println(ter +"\n ZAGOTOVLJENO.");
						else
							System.out.println(ter +"\n NI ZAGOTOVLJENO.");
					createReservation(pocitnice.get(i));
					}
				}
			}
			break;
		}
		case 'c': {
			for(int i=0;i<pocitnice.size();i++)
			{
				if(pocitnice.get(i).getTermini().size() > 0 && pocitnice.get(i) instanceof PocitnicePotovanje)
				{
					aliObstajajoPocitnice = true;
					System.out.println( flag ? pocitnice.get(i) : pocitnice.get(i).toStringUporabnik());
					System.out.println("Prosti so naslednji termini: ");
					for(Termin ter: pocitnice.get(i).getTermini()) {
						if(stRezervacij(pocitnice.get(i)) == pocitnice.get(i).getProstaMesta())
							System.out.println("ZAGOTOVLJENO.");
						else if(stRezervacij(pocitnice.get(i)) < pocitnice.get(i).getProstaMesta())
							System.out.println("SKORAJ ZAGOTOVLJENO.");
						else
							System.out.println("NI ZAGOTOVLJENO.");
					createReservation(pocitnice.get(i));
					}
				}
			}
			break;
		}
		case 'd': {
			for(int i=0;i<pocitnice.size();i++)
			{
				if(pocitnice.get(i).getTermini().size() > 0 && pocitnice.get(i) instanceof PocitniceKampiranje)
				{
					aliObstajajoPocitnice = true;
					System.out.println( flag ? pocitnice.get(i) : pocitnice.get(i).toStringUporabnik());
					System.out.println("Prosti so naslednji termini: ");
					for(Termin ter: pocitnice.get(i).getTermini()) {
						if(stRezervacij(pocitnice.get(i)) == pocitnice.get(i).getProstaMesta())
							System.out.println("ZAGOTOVLJENO.");
						else if(stRezervacij(pocitnice.get(i)) < pocitnice.get(i).getProstaMesta())
							System.out.println("SKORAJ ZAGOTOVLJENO.");
						else
							System.out.println("NI ZAGOTOVLJENO.");
						createReservation(pocitnice.get(i));
						}
				}
			}
			break;
		}
		
		default:
			System.out.println("ERROR:Te crke ni blo u tabeli izbir!.");
		}
	
		System.out.println(aliObstajajoPocitnice ? "" : "ERROR 404: Vacation not found...");
	}
	public static void createReservation(Pocitnice obj) throws IOException {
        br = new BufferedReader(new InputStreamReader(System.in));

		int stOdraslih = 0;
        int stOtrok = 0;

		char ch = ' ';

		System.out.println("Zelite ustvariti novo rezervacijo? ");
		System.out.println("Vnesite 'r' ce zelite ustvariti novo rezervacijo.");
		System.out.println("Vseite 'z' za prekinitev programa.");
		System.out.print("Vpisite izbiro: ");
		ch = (char)br.read();
		br.readLine();
		
		if(ch == 'r') {
			System.out.print("Koliko odraslih oseb: ");
			stOdraslih = betterIntegerParser_helper(br.readLine());
			System.out.print("Koliko pa otrok: ");
			stOtrok = betterIntegerParser_helper(br.readLine());
			
			if(stOdraslih + stOtrok < obj.getProstaMesta() - stRezervacij(obj)) {

			obj.getRezervacije().add(new Rezervacija(uporabnik.getIme(),uporabnik.getUporabniskoIme(), stOdraslih, stOtrok));
			System.out.println("Rezervacija je bila uspesna.");

			}else {
				System.out.println("Rezervacija je bila nesupesna. Prevec vas je.");
			}
		}
	}
	public static void izpisVsehRezervacij() {
		boolean rezervacij = false;

		for(Pocitnice obj : pocitnice)
		   if(obj.getRezervacije() != null && !obj.getRezervacije().isEmpty())

			for(Rezervacija obj2 :obj.getRezervacije())

				if(obj2.getUporabnik().equals(uporabnik.getUporabniskoIme())) {
					System.out.println("Na voljo:  \n" + obj.toStringUporabnik() +"\nNa voljo za iskano: \n" + obj2 );
					rezervacij = true;
				}
					else {
							System.out.println("Nobenih rezervacij ni v sistemu.");
		   }
		System.out.println(rezervacij ? "" : "Nobenih rezervacij ni v sistemu."); 
	}
	
	public static void iskanjePoID() throws IOException {
		int id = 0;
		br = new BufferedReader(new InputStreamReader(System.in));
		System.out.printf("Vnesite ID pocitnic: ");
		id = betterIntegerParser_helper(br.readLine());
		
		for(Pocitnice poc:pocitnice)
			if(poc.getId() == id )
				{
				System.out.print(poc);
				return;
				}
		System.out.println("ID: " + id + "ne obstaja v sistemu.");}
	
	public static void kreirajNovePocitnice() throws IOException {
		char ch = ' ';

		int id = 0,dan = 0, mesec = 0, prostihMest = 0;
		double cena = 0.0;
		String drzava = "";
		boolean value1=false,value2=false,f=true;
		
		br = new BufferedReader(new InputStreamReader(System.in));
		System.out.printf("Vnesite ID pocitnic: ");
		id = betterIntegerParser_helper(br.readLine());
		System.out.printf("Vnesite dan: ");
		dan = betterIntegerParser_helper(br.readLine());
		System.out.printf("Vnesite mesec: ");
		mesec = betterIntegerParser_helper(br.readLine());
		System.out.printf("Vnesite stevilo otrok in odraslih skupaj: ");
		prostihMest = betterIntegerParser_helper(br.readLine());
		System.out.printf("Vnesite ceno: ");
		cena = betterDoubleParser_helper(br.readLine());
		System.out.printf("Vnesite drzavo: ");
		drzava = br.readLine();
		while(f) {
			System.out.println("Vnesite podskupino pocitnic: ");
			System.out.println("Na voljo so naslednji tipi: ");
			System.out.println("b -> krizarjanje: ");
			System.out.println("c -> potovanje: ");
			System.out.println("d -> alpinizem: ");
			System.out.println("e -> kampiranje: ");
			ch = (char) br.read();
			br.readLine();
			switch (ch) {
				case 'a':
					pocitnice.add(new Pocitnice(dan, mesec, id, prostihMest, drzava, cena, new ArrayList<Termin>(), new ArrayList<Rezervacija>()));
					System.out.printf("Vacation saved.%n");
					f = false;
					break;
				case 'b':
					System.out.printf("Dobri reviewi: ");
					value1 = betterBooleanParser_helper(br.readLine());
					System.out.printf("All-inclusive paket: ");
					value2 = betterBooleanParser_helper(br.readLine());
					pocitnice.add(new PocitniceKrizarjenje(dan, mesec, id, prostihMest, drzava, cena, new ArrayList<Termin>(), new ArrayList<Rezervacija>(),value1,value2));
					System.out.printf("Vacation saved.%n");
					f = false;
					break;
				case 'c':
					System.out.printf("Eksoticno potovanje: ");
					value1 = betterBooleanParser_helper(br.readLine());
					System.out.printf("Varno Potovanje: ");
					value2 = betterBooleanParser_helper(br.readLine());
					pocitnice.add(new PocitnicePotovanje(dan, mesec, id, prostihMest, drzava, cena, new ArrayList<Termin>(), new ArrayList<Rezervacija>(),value1,value2));
					System.out.printf("Vacation saved.%n");
					f = false;
					break;
				case 'd':
					System.out.printf("Dvatisocaki: ");
					value1 = betterBooleanParser_helper(br.readLine());
					System.out.printf("Ustrezna oprema: ");
					value2 = betterBooleanParser_helper(br.readLine());
					pocitnice.add(new PocitniceAlpinizem(dan, mesec, id, prostihMest, drzava, cena, new ArrayList<Termin>(), new ArrayList<Rezervacija>(),value1,value2));
					System.out.printf("Vacation saved.%n");
					f = false;
					break;
				case 'e':
					System.out.printf("Cena najema sotora je: ");
					value1 = betterBooleanParser_helper(br.readLine());
					System.out.printf("Cena najema colna je: ");
					value2 = betterBooleanParser_helper(br.readLine());
					pocitnice.add(new PocitniceKampiranje(dan, mesec, id, prostihMest, drzava, cena, new ArrayList<Termin>(), new ArrayList<Rezervacija>(),value1,value2));
					System.out.printf("Vacation saved.%n");
					f = false;
					break;
			default:
				throw new IllegalArgumentException("ERROR 404: " + ch);
			}
		}
		

		
	}
	public static void odstraniPocitnice() throws IOException {
        br = new BufferedReader(new InputStreamReader(System.in));

		int id = 0;
		System.out.print("ID-pocitnic: ");
		id = betterIntegerParser_helper(br.readLine());
		for(Pocitnice obj: pocitnice)
			if(obj.getId() == id)
				{
					pocitnice.remove(obj);
					System.out.println("Vacation deleted!");
					return;
				}
		System.out.println("ID:" + id +" ne obstaja.");
	}
	public static void dodajTermin() throws IOException {
        br = new BufferedReader(new InputStreamReader(System.in));


		int id = 0,dan = 0, mesec = 0, prihod = 0, odhod = 0;
		System.out.print("ID-pocitnic: ");
		id = betterIntegerParser_helper(br.readLine());
		for(Pocitnice obj: pocitnice)
			if(obj.getId() == id)
				{
					
					System.out.print("Vnesite dan termina: ");
					dan = betterIntegerParser_helper(br.readLine());
					System.out.print("Vnesite mesec termina: ");
					mesec = betterIntegerParser_helper(br.readLine());
					System.out.print("Ura prihoda termina: ");
					prihod = betterIntegerParser_helper(br.readLine());
					System.out.print("Ura odhoda termina: ");
					odhod = betterIntegerParser_helper(br.readLine());
					obj.getTermini().add(new Termin(dan, mesec, prihod, odhod));
					System.out.println("SUCCESS!.");
					return;
				}
		System.out.println("ID:" + id +" ne obstaja.");
	}
	
	public static void odstraniTermin() throws IOException {
        br = new BufferedReader(new InputStreamReader(System.in));



		int id = 0,dan = 0, mesec = 0, prihod = 0, odhod = 0;
		boolean aliTerminObstaja = false;
		System.out.print("ID: ");
		id = betterIntegerParser_helper(br.readLine());
		for(Pocitnice obj: pocitnice)
			if(obj.getId() == id)
				{
					
					System.out.print("Vnesite dan termina: ");
					dan = betterIntegerParser_helper(br.readLine());
					System.out.print("Vnesite mesec termina: ");
					mesec = betterIntegerParser_helper(br.readLine());
					System.out.print("Ura prihoda termina: ");
					prihod = betterIntegerParser_helper(br.readLine());
					System.out.print("Ura odhoda termina: ");
					odhod = betterIntegerParser_helper(br.readLine());
					aliTerminObstaja = pocitnice.get(id).getTermini().remove(new Termin(dan, mesec, prihod, odhod));
					if(aliTerminObstaja)
						System.out.println("Termin je odstranjen.");
					else
						System.out.println("V sistemu tega termina ni.");
					return;
				}
		System.out.println("ID:" + id +" ne obstaja.");
	}
	public static void spremeniCeno() throws IOException {
		int id = 0,cena = 0;
		br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("ID: ");
		id = betterIntegerParser_helper(br.readLine());
		for(Pocitnice obj: pocitnice)
			if(obj.getId() == id)
				{
					System.out.print("Spremenjena cena: ");
					cena = betterIntegerParser_helper(br.readLine());
					obj.setCena(cena);
					System.out.print("SUCCESS!!.\n");
					return;
				}
		System.out.println("ID:" + id +" ne obstaja.");
	}
	
	private static int betterIntegerParser_helper(String str) {
		try {
			return Integer.parseInt(str);
		}catch(Exception  e){
			System.out.println("Nepravilen vnos podatkov, zato bo avtomaticno generirana vrednost 0.");
			return 0;
		}
	}
	private static double betterDoubleParser_helper(String str) {
		try {
			return Double.parseDouble(str);
		}catch(Exception e){
			System.out.println("Nepravilen vnos podatkov, zato bo avtomaticno generirana vrednost 0.");
			return 0.0;
		}
	}
	private static boolean betterBooleanParser_helper(String str) {
		try {
			return Boolean.parseBoolean(str);
		}catch(Exception e){
			System.out.println("Nepravilen vnos podatkov, zato bo avtomaticno generirana vrednost 0.");
			return false;
		}
	}
	
	public static void izpisVsehPocitnic() throws ClassNotFoundException, IOException {
		System.out.println(pocitnice);
		System.out.println("Vseh pocitnic je: " + pocitnice.size());
	}
	public static void terminirajProgram() throws IOException{
		System.out.println("Program je bil terminiran!");
		if(pw != null && br !=null) {
			pw.close();
			br.close();
		}
		
	}
    public static void shraniSpremembo() {
    }

{}
}
 
    

