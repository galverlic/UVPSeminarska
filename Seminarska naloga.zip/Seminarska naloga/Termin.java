import java.io.Serializable;

public class Termin implements Serializable{
	

	private static final long serialVersionUID = 1L;
	private int dan,mesec;
	private int danPrihoda,danOdhoda;
	

	@Override
	public String toString() {
		return String.format("Termin: Prihod: %d.%d %d , Odhod :  %d", dan,mesec,danPrihoda,danOdhoda);
	}
	
	public Termin(int dan, int mesec, int danPrihoda, int danOdhoda) {
		this.dan = dan;
		this.mesec = mesec;
		this.danPrihoda = danPrihoda;
		this.danOdhoda = danOdhoda;
	}
	public int getDan() {
		return dan;
	}
	public void setDan(int dan) {
		this.dan = dan;
	}
	public int getMesec() {
		return mesec;
	}
	public void setMesec(int mesec) {
		this.mesec = mesec;
	}
	public int getdanPrihoda() {
		return danPrihoda;
	}
	public void setdanPrihoda(int danPrihoda) {
		this.danPrihoda = danPrihoda;
	}
	public int getdanOdhoda() {
		return danOdhoda;
	}
	public void setdanOdhoda(int danOdhoda) {
		this.danOdhoda = danOdhoda;
	}
	
	
	
	
}
