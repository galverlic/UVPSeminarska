import java.util.ArrayList;

public class PocitniceKrizarjenje extends Pocitnice {

	private static final long serialVersionUID = 1L;
	private boolean dobriReviewi; 
	private boolean allInclusivePaket;
	
	
	@Override
	public String toString() {
		
		return super.toString()+
				String.format("Dobri reviewi: %b%n", dobriReviewi)
		      + String.format("All Inclusive paket: %b%n", allInclusivePaket);
			
	}
	
	public PocitniceKrizarjenje(int dan, int mesec, int id, int prostihMest, String drzava, double cena,
			ArrayList<Termin> termini, ArrayList<Rezervacija> rezervacije) {
		super(dan, mesec, id, prostihMest, drzava, cena, termini, rezervacije);
	
	}
	
	
	public PocitniceKrizarjenje(int dan, int mesec, int id, int prostihMest, String drzava, double cena,
			ArrayList<Termin> termini, ArrayList<Rezervacija> rezervacije, Boolean dobriReviewi,
			boolean allInclusivePaket) {
		super(dan, mesec, id, prostihMest, drzava, cena, termini, rezervacije);
		this.dobriReviewi = dobriReviewi;
		this.allInclusivePaket = allInclusivePaket;
	}


	public boolean isdobriReviewi() {
		return dobriReviewi;
	}

	public void setdobriReviewi(Boolean dobriReviewi) {
		this.dobriReviewi = dobriReviewi;
	}

	public boolean isallInclusivePaket() {
		return allInclusivePaket;
	}

	public void setallInclusivePaket(boolean allInclusivePaket) {
		this.allInclusivePaket = allInclusivePaket;
	}
}
