import java.io.Serializable;

public class Rezervacija implements Serializable {
	
	

    private static final long serialVersionUID = 1L;
	private String ime,uporabnik;
	private int stOdraslih = 0;
    private int stOtrok = 0;
	
	@Override
	public String toString() {

		return String.format("Rezervacija za %s rezervira mesta za stOdraslih: %d  in stOtrok: %d.",uporabnik,stOdraslih, stOtrok);
	}
	
	
	public Rezervacija(String ime, String uporabnik, int stOdraslih, int stOtrok) {
		this.ime = ime;
		this.uporabnik = uporabnik;
		this.stOdraslih = stOdraslih;
        this.stOtrok = stOtrok;
	}

	public String getIme() {
        return ime;
    }


    public void setIme(String ime) {
        this.ime = ime;
    }


    public String getUporabnik() {
        return uporabnik;
    }


    public void setUporabnik(String uporabnik) {
        this.uporabnik = uporabnik;
    }


    public int getStOdraslih() {
        return stOdraslih;
    }


    public void setStOdraslih(int stOdraslih) {
        this.stOdraslih = stOdraslih;
    }


    public int getStOtrok() {
        return stOtrok;
    }


    public void setStOtrok(int stOtrok) {
        this.stOtrok = stOtrok;
    }
}
