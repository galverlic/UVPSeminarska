import java.io.Serializable;
import java.util.ArrayList;

public class Pocitnice implements Serializable{
	
	private static final long serialVersionUID = 1L;
    private int id;
	private int dan;
    private int mesec;
    private int prostaMesta;
	private String drzava;
	private double cena;
	private ArrayList<Termin> termini = new ArrayList<>();
	private ArrayList<Rezervacija> rezervacije = new ArrayList<>();
	
	
	
	@Override
	public String toString() {
		return String.format("IdentifikacijaskaStevilka:" ,id)
			  +String.format("Dan: ",dan)
			  +String.format("Mesec:",mesec)
			  +String.format("Cena: ", cena)
			  +String.format("St prostih mest:",prostaMesta)
			  +String.format("Drzava:", drzava)
			  ;
	}
    // za navadne uporabnike aplikacije
	public String toStringUporabnik() {
		return 
			  String.format("Dan vasega potovanja: ",dan)
			  +String.format("Mesec vasega potovanja: %d%n",mesec)
			  +String.format("Cena: %.2f�%n", cena)
			  +String.format("Kam bi potovali?: %s%n", drzava)
			  ;
	}
	
	
	
	public Pocitnice(int dan, int mesec, int id, int prostaMesta, String drzava, double cena, ArrayList<Termin> termini,
			ArrayList<Rezervacija> rezervacije) {
		this.dan = dan;
		this.mesec = mesec;
		this.id = id;
		this.prostaMesta = prostaMesta;
		this.drzava = drzava;
		this.cena = cena;
		this.termini = termini;
		this.rezervacije = rezervacije;
	}

    //getters

    public int getId() {
		return id;
	}

	public int getDan() {
		return dan;
	}

    public int getMesec() {
		return mesec;

	}
    public int getProstaMesta() {
		return prostaMesta;
	}

	public String getDrzava() {
		return drzava;
	}

	public double getCena() {
		return cena;
	}
    public ArrayList<Rezervacija> getRezervacije() {
		return rezervacije;
	}

	public ArrayList<Termin> getTermini() {
		return termini;
	}

// setters
    public void setId(int id) {
        this.id = id;
    }
	public void setDan(int dan) {
		this.dan = dan;
	}
	public void setMesec(int mesec) {
		this.mesec = mesec;
	}

	public void setProstaMesta(int prostaMesta) {
		this.prostaMesta = prostaMesta;
	}
	
    public void setDrzava(String drzava) {
		this.drzava = drzava;
	}

	
	public void setCena(double cena) {
		this.cena = cena;
	}

	public void setTermini(ArrayList<Termin> termini) {
		this.termini = termini;
	}


	public void setRezervacije(ArrayList<Rezervacija> rezervacije) {
		this.rezervacije = rezervacije;
	}
	
}
