
import java.io.*;
import java.util.ArrayList;
import java.util.Collection;



public class IOReadAndWrite implements Serializable{
	private static final long serialVersionUID = 1L;
	private static FileOutputStream fo;
	private static ObjectOutputStream oo;
	private static FileInputStream fi;
	private static ObjectInputStream oi;
	
	
	public static void saveObject(String pot,ArrayList<?> anyArrayList) throws IOException {
		fo = new FileOutputStream(new File(pot)); 
		oo = new ObjectOutputStream(fo);
		oo.writeObject(anyArrayList);
		fo.close();
		oo.close();
	}
	
	
	@SuppressWarnings("unchecked")
	public static <T>  void  readLoadObject(String pot,ArrayList<T> anyArrayList)  throws IOException, ClassNotFoundException  {
		File fileChecker = new File(pot);
		
		if(fileChecker.isFile() && fileChecker.length() == 0) {
			anyArrayList.clear();
		}
		else {
		fi = new FileInputStream( fileChecker);
		oi = new ObjectInputStream(fi);
	
		anyArrayList.addAll( (Collection<? extends T>) oi.readObject());
	    	fi.close();
		oi.close();
		}

	}

	
}
