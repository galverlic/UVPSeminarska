import java.util.ArrayList;

public class PocitnicePotovanje  extends Pocitnice{
	
    private static final long serialVersionUID = 1L;
	private boolean eksoticnoPotovanje; 
	private boolean varnoPotovanje;

	
	@Override
	public String toString() {
		
		return super.toString()+
				String.format("eksoticnoPotovanje: %b%n", eksoticnoPotovanje)
		      + String.format("varnoPotovanje:%b%n", varnoPotovanje);
			
	}
	
	
	public PocitnicePotovanje(int dan, int mesec, int id, int prostihMest, String drzava, double cena,
			ArrayList<Termin> termini, ArrayList<Rezervacija> rezervacije) {
		super(dan, mesec, id, prostihMest, drzava, cena, termini, rezervacije);
		
	}
	public PocitnicePotovanje(int dan, int mesec, int id, int prostihMest, String drzava, double cena,
			ArrayList<Termin> termini, ArrayList<Rezervacija> rezervacije, boolean eksoticnoPotovanje,
			Boolean varnoPotovanje) {
		super(dan, mesec, id, prostihMest, drzava, cena, termini, rezervacije);
		this.eksoticnoPotovanje = eksoticnoPotovanje;
        this.varnoPotovanje = varnoPotovanje;
	}

	public boolean isEksoticnoPotovanje() {
		return eksoticnoPotovanje;
	}

	public void setEksoticnoPotovanje(boolean eksoticnoPotovanje) {
		this.eksoticnoPotovanje = eksoticnoPotovanje;
	}

	public boolean varnoPotovanje() {
	    return varnoPotovanje;
	}

	public void varnoPotovanje(boolean varnoPotovanje) {
        this.varnoPotovanje = varnoPotovanje;
    }
	
}
		
	

 
    

