import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class UporabnikVmesnik {
		
	private static final BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	private static final String pot = UporabniskiVmesnik.pot;
	
	public static void uporabnik(ArrayList<Uporabnik> uporabniki) throws IOException, ClassNotFoundException {
		char izbira;
		while(true) 
		{
			System.out.println("Iskalnik pocitnic");
			System.out.println("c -> Iskanje pocitnic po casovnem okvirju.");
			System.out.println("d -> Iskanje poctnic po drzavi");
			System.out.println("x -> Iscanje pocitnic po cenovnem okvirju.");
			System.out.println("t -> Iscanje pocitnic po tipu pocitnic.");
			System.out.println("u -> Ustvari rezervacijo.");
			System.out.println("i -> Izpis vseh rezervacij.");
			System.out.println("z -> Odjava iz iskalnika pocitnic.");
			izbira = (char) br.read();
			switch (izbira)
			{
				case 'c': 
					TuristicnaAgencija.iskanjeCasovniOkvir(false);
					br.readLine();
					break;
				case 'd':
					TuristicnaAgencija.iskanjeDrzava(false);
					br.readLine();
					break;
				case 'x':
					TuristicnaAgencija.iskanjeCenovniOkvir(false);
					br.readLine();
					break;
				case 't':
					TuristicnaAgencija.iskanjePoTipuPocitnic(false);
					br.readLine();
					break;
				case 'i':
					TuristicnaAgencija.izpisVsehRezervacij();
					br.readLine();
					break;
				case 'z':
					TuristicnaAgencija.save();
					IORazred.save(pot, uporabniki);
					UporabniskiVmesnik.main(new String[]{"true"});
					break;
				default:
					System.out.println("ERROR 404:Izbrali ste napacno opcijo.");
			}
		}
	}
	public static void admin(ArrayList<Uporabnik> uporabniki) throws IOException, ClassNotFoundException {
		char izbira;
		while(true) 
		{
			System.out.println("Iskalnik pocitnic(administrator)");
			System.out.println("c -> Iskanje pocitnic po casovnem okvirju.");
			System.out.println("d -> Iskanje poctnic po drzavi");
			System.out.println("x -> Iscanje pocitnic po cenovnem okvirju.");
			System.out.println("t -> Iscanje pocitnic po tipu pocitnic.");
			System.out.println("u -> Ustvari rezervacijo.");
			System.out.println("i -> Izpis vseh rezervacij.");
			System.out.println("a -> Iskanje pocitnic po ID stevilki.");
			System.out.println("b -> Kreiraj nove pocitnice.");
			System.out.println("o->  Odstrani pocitnice.");
			System.out.println("g -> Dodaj termin.");
            System.out.println("f -> Odstrani termin.");
			System.out.println("h -> Spremeni ceno pocitnic.");
			System.out.println("j -> Shrani spremembo.");
			System.out.println("k -> Kreiraj nov adiministratorski racun.");
			System.out.println("m -> Odstrani racun.");
			System.out.println("n -> Izpis vseh pocitnic.");
			System.out.println("z -> Odjava iz iskalnika pocitnic.");
			izbira = (char) br.read();
			switch (izbira)
			{
				case 'c': 
					TuristicnaAgencija.iskanjeCasovniOkvir(false);
					//br.readLine();
					break;
				case 'd':
					TuristicnaAgencija.iskanjeDrzava(false);
					//br.readLine();
					break;
				case 'x':
					TuristicnaAgencija.iskanjeCenovniOkvir(false);
					//br.readLine();
					break;
				case 't':
					TuristicnaAgencija.iskanjePoTipuPocitnic(false);
					//br.readLine();
					break;
				case 'i':
					TuristicnaAgencija.izpisVsehRezervacij();
					//br.readLine();
					break;
				case 'a':
					TuristicnaAgencija.iskanjePoID();
					br.readLine();
					break;
				case 'b':
					TuristicnaAgencija.kreirajNovePocitnice();
					br.readLine();
					break;
				case 'o':
					TuristicnaAgencija.odstraniPocitnice();
					br.readLine();
					break;
				case 'g':
					TuristicnaAgencija.dodajTermin();
					br.readLine();
					break;
				case 'f':
					TuristicnaAgencija.odstraniTermin();
					br.readLine();
					break;
			    case 'h':
			    	TuristicnaAgencija.spremeniCeno();
			    	br.readLine();
				case 'j':
					TuristicnaAgencija.shraniSpremembo();
					br.readLine();
					break;
				case 'k':
					IORazred.registrirajAdministratorja(uporabniki, true);
					br.readLine();
					break;
			    case 'm':
			    	IORazred.odstraniUporabnika(uporabniki);
			         br.readLine();
					break;
			    case 'n':
			    	 TuristicnaAgencija.izpisVsehPocitnic();
			    	 br.readLine();
			    	 break;
				case 'z':
					TuristicnaAgencija.save();
					IORazred.save(pot, uporabniki);
					UporabniskiVmesnik.main(new String[]{"true"});
					break;
				default:
					System.out.println("ERROR 404: Izbrali ste napacno opcijo, prosim kliknite eden od moznih izbir");
			}
		}
	}
	
}
