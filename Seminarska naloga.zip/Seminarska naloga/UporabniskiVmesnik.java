import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class UporabniskiVmesnik {

	//metode 
		static ArrayList<Uporabnik> uporabniki =  new ArrayList<Uporabnik>();
		public final static String pot = "uporabniki.txt";
		public final static String pot2 = "pocitnice.txt";
		public static boolean error = false;

        static InputStreamReader isr = new InputStreamReader(System.in);
		static BufferedReader br = new BufferedReader(isr);	


		public static void main(String[] args) throws IOException, ClassNotFoundException {

        
        	if(error) {
            	IORazred.save(pot, uporabniki);
				TuristicnaAgencija.load();
				error=true;
        	}
        

        if( args !=null && args.length > 0 && Boolean.parseBoolean(args[0])==true ) br.readLine(); 
        System.out.println("DOBRODOSLI V TURISTICNI AGENCIJI SKY'S THE LIMIT!");
		System.out.println("**********************");

		char izbira;
		
		while(true) 
		{
			System.out.println("Izberite eno od izbir: ");
			System.out.println("Pritisni(n) za vnos novega uporabnika.");
			System.out.println("Pritisni(u) za izpis uporabnikov.");
			System.out.println("Pritisni(p) za prijavo registriranih uporabnikov.");
			System.out.println("Pritisni(q) za prekinitev programa.");

			izbira = (char) br.read();
			switch (izbira)
			{
				case 'n': 
					IORazred.registrirajUporabnika(uporabniki,false);
					IORazred.save(pot, uporabniki);
					break;
				case 'u':
					IORazred.izpisUporabnikov(uporabniki);
					break;
				case 'p':
					IORazred.prijavaUspesna(uporabniki);
					break;
				case 'q':
					TuristicnaAgencija.save();
					IORazred.save(pot, uporabniki);
					IORazred.terminirajProgram();
					break;

				case 'g':
                    ustvariAdmininistratorInUporabnik();
					ustvariPocitnice();
					
					break;
				default:
                System.out.println("Pritisnili ste napacno izbiro!");
                System.out.println();
			}
		}
	}
	//prvi method da se kreira admin ali uporanik
	public static void ustvariAdmininistratorInUporabnik()  throws IOException, ClassNotFoundException{
		if(!IORazred.uporabniskoZeObstaja(uporabniki,"admin") ) {
			uporabniki.add(new Uporabnik("janez","novak","janez.novak","Geslo1",false));
			uporabniki.add(new Uporabnik("gal","verlic","gal.verlic","Geslo2",true));  
			
		IORazred.save(pot, uporabniki);
		}
	}
	//druga metoda, ki doloca vrsto poctnic
	public static void ustvariPocitnice() throws ClassNotFoundException, IOException {

		
	    for(int i=1;i<8;i++)
			TuristicnaAgencija.pocitnice.add(new Pocitnice(i*1, i*2, i*1, i*100, "Slovenija", i*1000, ustvariRezervacijo(), null));


		TuristicnaAgencija.pocitnice.add(new PocitniceKampiranje(2, 4, 9, 2, "Hrvaska", 10000, ustvariRezervacijo(), null,false,false));
		TuristicnaAgencija.pocitnice.add(new PocitniceAlpinizem(4, 2, 3, 1, "Avstrija", 100, ustvariRezervacijo(), null,true,false));
		TuristicnaAgencija.pocitnice.add(new PocitnicePotovanje(1, 2, 3, 5, "Tajska", 1000, ustvariRezervacijo(), null,false,true));
		TuristicnaAgencija.pocitnice.add(new PocitniceKrizarjenje(5, 2, 4, 5, "Grcija", 500, ustvariRezervacijo(), null,false,true));

		TuristicnaAgencija.save();

	}
	//metoda, ki doloca cas dopusta
	public static ArrayList<Termin> ustvariRezervacijo(){
		ArrayList<Termin> datum = new ArrayList<>();
		// 1.dan, prvi mesec, zadnji dan, zadnji mesec
		datum.add(new Termin(10,5,18,5));
		datum.add(new Termin(3,3,18,3));
		datum.add(new Termin(21,4,5,5));

		return datum;
	}
	
}



    


























