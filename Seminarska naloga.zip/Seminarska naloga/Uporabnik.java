public class Uporabnik {
   
    private String ime;
    private String priimek;
    private String uporabniskoIme;
    private String geslo;
    private boolean aliJeAdministrator;

    public Uporabnik(String ime, String priimek, String uporabniskoIme, String geslo, boolean aliJeAdministrator) {
        this.ime = ime;
        this.priimek = priimek;
        this.uporabniskoIme = uporabniskoIme;
        this.geslo = geslo;
        this.aliJeAdministrator = aliJeAdministrator; 
    }

    // Setters(rabimo ker so variables private, setter metoda setta value)


    public void setIme(String ime) {
        this.ime = ime;
    }

    public void setPriimek(String priimek) {
        this.priimek = priimek;
    }

    public void setUporabniskoIme(String uporabniskoIme) {
        this.uporabniskoIme = uporabniskoIme;
    }

   
	public void setaliJeAdministrator(boolean aliJeAdministrator) {
		this.aliJeAdministrator = aliJeAdministrator;
	}

    public void setGeslo(String geslo) {
        this.geslo = geslo;
    }
    // Getters(vrne value variable-a)

    public boolean aliJeAdministrator() {
		return aliJeAdministrator();
	}

    public String getIme() {
        return this.ime;
    }

    public String getPriimek() {
        return this.priimek;
    }

    public String getUporabniskoIme() {
        return this.uporabniskoIme;
    }

    public String getGeslo() {
        return this.geslo;

    }

    public String skupajUporabnika() {
        return "Uporabnisko ime: " + this.uporabniskoIme + ", Ime in priimek uporabnika: "+ this.ime  + " " + this.priimek + " ,Administrator: " + (this.aliJeAdministrator ? "Da" : "Ne");
    }

    
    }
    
