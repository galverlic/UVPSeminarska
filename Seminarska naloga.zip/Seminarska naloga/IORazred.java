import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;



public class IORazred{
	private static BufferedReader br = null;
	private static PrintWriter pr = null;
    private static String ime = null, priimek = null;
	private static String uporabiskoIme = null, geslo = null;

	public static void read(String pot,ArrayList<Uporabnik> uporabniki) throws IOException, ClassNotFoundException {
		IOReadAndWrite.readLoadObject(pot, uporabniki);
	}
	public static void save(String pot,ArrayList<Uporabnik> uporabniki) throws IOException{
		IOReadAndWrite.saveObject(pot, uporabniki);
	}
	public static void registrirajUporabnika(ArrayList<Uporabnik> uporabniki,boolean f) throws IOException {
		br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Ime: ");
		ime = br.readLine();
		System.out.print("Priimek: ");
		priimek = br.readLine();
		System.out.print("Uporabnisko ime: ");
		uporabiskoIme = br.readLine();
		System.out.print("Geslo: ");
		geslo = br.readLine();

	    //preverimo ce uporabnisko ime ze obstaja	
		if(uporabniskoZeObstaja(uporabniki, uporabiskoIme))
			System.out.println("To uporabnisko ime ze obstaja. Prosim prijavite se s tem uporabniskim imenom.");
		else {
			uporabniki.add(f ? new Uporabnik(ime,priimek,uporabiskoIme,geslo,true) : new Uporabnik(ime,priimek,uporabiskoIme,geslo,false));
			System.out.println("Prijava je bila uspesna.");
		}
	}
    //prijava je uspesna
	public static void prijavaUspesna(ArrayList<Uporabnik> uporabniki) throws IOException, ClassNotFoundException  {
		br = new BufferedReader(new InputStreamReader(System.in));

		System.out.print("Vnesite uporabnisko ime: ");
		ime = br.readLine();
        //Ce uporabnisko ne obstaja(še)
		if(!uporabniskoZeObstaja(uporabniki, ime))
		{
			System.out.printf("ERROR:! Uporabnik: %s  ne obstaja! Prosim, ponovno vnesite pravilne podatke.%n", ime);
			return;
		}
		System.out.print("Vnesite geslo: ");
		priimek = br.readLine();
        //pomen: uporabnisko ime je enako ime in geslo je enako vnos 2
		for(Uporabnik obj: uporabniki)
			if(obj.getUporabniskoIme().equals(ime) && obj.getGeslo().equals(priimek))
            //ce je administrator, se shrani kot administrator
				if(obj.aliJeAdministrator()) {
					TuristicnaAgencija.uporabnik = obj;
					UporabnikVmesnik.admin(uporabniki);
			// ce ni-->se shrani kot (navaden) uporabnik		
				}
				else {
					TuristicnaAgencija.uporabnik = obj;
					UporabnikVmesnik.uporabnik(uporabniki);
					
				}
	}
    //odstrani uporabnika
	public static void odstraniUporabnika(ArrayList<Uporabnik> uporabniki) throws IOException{
		int admin_counter = prestej_Admine(uporabniki);
		System.out.println(admin_counter);
		System.out.print("Vnesite uporabnisko ime: ");
		ime = br.readLine();
		
		if(!uporabniskoZeObstaja(uporabniki, ime))
		{
			System.out.println("Uporabnik ne obstaja");
			return;
		}else {
				for(Uporabnik obj: uporabniki) {
					if(obj.getUporabniskoIme().equals(ime)) 
					{
						if(obj.aliJeAdministrator() && admin_counter > 1) 
						{
							admin_counter--;
							uporabniki.remove(obj);
						}
						else
							System.out.println("V sistemu more biti vsaj 1 admin.");
					}
					if(!obj.aliJeAdministrator())
							uporabniki.remove(obj);
				}
		}
	}

	public static int prestej_Admine(ArrayList<Uporabnik> uporabniki) {
		int admin_stevec = 0;
		for(Uporabnik obj: uporabniki)
			admin_stevec = obj.aliJeAdministrator() ? ++admin_stevec : admin_stevec;
		
		return admin_stevec;
	}
	
	
	public static boolean uporabniskoZeObstaja(ArrayList<Uporabnik> uporabniki,String input) {
		for(Uporabnik obj: uporabniki)
			if(obj.getUporabniskoIme().equals(input))
				return true;
		return false;
	};
	public static void izpisUporabnikov(ArrayList<Uporabnik> uporabniki) {
		System.out.print(Arrays.toString(uporabniki.toArray()).replace("[", "").replace("]", ""));
	}
	
	public static void terminirajProgram() throws IOException{

		System.out.println("Program je bil terminiran!");
		if(pr == null || br ==null)
			System.exit(0);
		else {
			pr.close();
			br.close();
			System.exit(0);
		}
	}
    public static void registrirajAdministratorja(ArrayList<Uporabnik> uporabniki, boolean b) {
    }
}
