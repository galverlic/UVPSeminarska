import java.util.ArrayList;

public class PocitniceKampiranje extends Pocitnice{
	
	private static final long serialVersionUID = 1L;
	private boolean najemBarke;
	private boolean wcTus;
	
	
	@Override
	public String toString() {
		
		return super.toString()+
				String.format("Vkljucen najem barke je: %b%n", najemBarke)
		       +String.format("WC in tus vklucena : %b%n", wcTus);
			
	}
	
	public PocitniceKampiranje(int id, int dan, int mesec, int prostihMest, String drzava, double cena,
			ArrayList<Termin> termini, ArrayList<Rezervacija> rezervacije) {
		super(dan, mesec, id, prostihMest, drzava, cena, termini, rezervacije);
	}
	public PocitniceKampiranje(int dan, int mesec, int id, int prostihMest, String drzava, double cena,
			ArrayList<Termin> termini, ArrayList<Rezervacija> rezervacije, boolean najemBarke, boolean wcTus) {
		super(dan, mesec, id, prostihMest, drzava, cena, termini, rezervacije);
		this.najemBarke = najemBarke;
		this.wcTus = wcTus;
	}
	
	
	public boolean najemBarke() {
		return najemBarke;
	}

	public void setnajemBarke(boolean najemBarke) {
		this.najemBarke = najemBarke;
	}


	public boolean WcTus() {
		return wcTus;
	}
	public void setWcTus(boolean wcTus) {
		this.wcTus = wcTus;
	}

}
