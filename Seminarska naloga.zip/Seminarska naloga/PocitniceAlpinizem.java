import java.util.ArrayList;

public class PocitniceAlpinizem  extends Pocitnice{
	
    private static final long serialVersionUID = 1L;
	private boolean dvatisocaki; 
	private boolean ustreznaOprema;

	
	@Override
	public String toString() {
		
		return super.toString()+
				String.format("dvatisocaki: %b%n", dvatisocaki)
		      + String.format("ustreznaOprema:%b%n", ustreznaOprema);
			
	}
	
	
	public PocitniceAlpinizem(int dan, int mesec, int id, int prostihMest, String drzava, double cena,
			ArrayList<Termin> termini, ArrayList<Rezervacija> rezervacije) {
		super(dan, mesec, id, prostihMest, drzava, cena, termini, rezervacije);
		
	}
	public PocitniceAlpinizem(int dan, int mesec, int id, int prostihMest, String drzava, double cena,
			ArrayList<Termin> termini, ArrayList<Rezervacija> rezervacije, boolean dvatisocaki,
			Boolean ustreznaOprema) {
		super(dan, mesec, id, prostihMest, drzava, cena, termini, rezervacije);
		this.dvatisocaki = dvatisocaki;
        this.ustreznaOprema = ustreznaOprema;
	}

	public boolean isEksoticnoPotovanje() {
		return dvatisocaki;
	}

	public void setEksoticnoPotovanje(boolean dvatisocaki) {
		this.dvatisocaki = dvatisocaki;
	}

	public boolean ustreznaOprema() {
	    return ustreznaOprema;
	}

	public void ustreznaOprema(boolean ustreznaOprema) {
        this.ustreznaOprema = ustreznaOprema;
    }
	
}
		
	

 
    

